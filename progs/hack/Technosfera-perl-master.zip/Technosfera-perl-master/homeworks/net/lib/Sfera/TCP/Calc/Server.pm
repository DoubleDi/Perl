package Sfera::TCP::Calc::Server;

use strict;
use IO::Socket;
use Sfera::TCP::Calc;

sub start_server {
	my $pkg = shift;
	my $port = shift;
	#init server
	#accept connection
	#fork
	#receive 
	#Sfera::TCP::Calc->unpack_header(...)
	#Sfera::TCP::Calc->unpack_message(...)
	#process
	#Sfera::TCP::Calc->pack_header(...)
	#Sfera::TCP::Calc->pack_message(...)
	#response
}

1;

